#include <RcppArmadillo.h>

using namespace Rcpp;
using namespace arma;

double abs3(double x){
  double abs_x = x;
  if(abs_x<0) abs_x = -abs_x;
  return abs_x;
}

arma::vec AccessListVectors_vec(List list, std::string element_name){
  SEXP foo = wrap(as<NumericVector>(list[element_name]));
  arma::vec vec_out = Rcpp::as<arma::vec>(foo);
  return vec_out;
}

arma::mat AccessListVectors_mat(List list, std::string element_name){
  SEXP foo = wrap(as<NumericMatrix>(list[element_name]));
  arma::mat mat_out = Rcpp::as<arma::mat>(foo);
  return mat_out;
}


arma::cube array2cube_2( SEXP myArray ) {
  
  Rcpp::NumericVector vecArray(myArray);
  Rcpp::IntegerVector arrayDims = vecArray.attr("dim");
  
  arma::cube cubeArray(vecArray.begin(), arrayDims[0], arrayDims[1], arrayDims[2], false);
  
  return(cubeArray);
  
}

const double log2pi = std::log(2.0 * M_PI);

//[[Rcpp::export]]
arma::vec getDelta(arma::mat gamma,int m){
  arma::mat I = eye(m,m);
  arma::mat Umat = ones(m,m);
  
  arma::vec Uvec(m);Uvec.fill(1);
  
  arma::mat foo = (I - gamma + Umat).t();
  
  arma::mat delta = (foo).i() * Uvec;
  
  return delta;
}

List StartingValueEM(arma::vec vY, int K){
  
  arma::vec weights(K);
  
  double dMu     = mean(vY) ;
  double dSigma2 = var(vY)  ;
  
  double start = 0.8;
  double end   = 1.2;
  double by    = (end-start)/(K*1.0);
  
  double foo = start - by;
  
  arma::vec vMu(K);
  arma::vec vSigma2(K);
  
  arma::mat mGamma(K,K);
  
  mGamma.fill(0.1/(K-1.0));
  
  for(int j=0;j<K;j++){
    vMu(j)      = dMu*foo;
    vSigma2(j)  = dSigma2*foo;
    mGamma(j,j) = 0.9;
    foo += by;
  }
  
  List out;
  out["vMu"]     = vMu;
  out["vSigma2"] = vSigma2;
  out["mGamma"]  = mGamma;
  
  return out;
  
}

arma::mat GaussianLk(arma::vec vY, arma::vec vMu, arma::vec vSigma2, int K, int T, int lg){
  
  arma::mat lk(T,K);
  
  int i,j;
  
  for(i=0;i<T;i++){
    for(j=0;j<K;j++){
      lk(i,j)=R::dnorm4(vY(i),vMu(j),sqrt(vSigma2(j)),lg);
      if(lk(i,j)<1e-250 && !lg) lk(i,j) = 1e-250;
    }
  }
  
  return lk;
}

List FFBS(arma::mat allprobs, arma::vec delta, arma::mat mGamma, int K, int T){
  
  arma::mat lalpha=zeros(K,T);
  arma::mat lbeta=zeros(K,T);
  
  arma::vec foo(K);
  double sumfoo,lscale;
  int i;
  
  foo    = delta % allprobs.row(0).t();
  sumfoo = sum(foo);
  lscale = log(sumfoo);
  foo    = foo/sumfoo ;
  
  lalpha.col(0) = log(foo)+lscale;
  for(i=1;i<T;i++){
    foo           = (foo.t() * mGamma).t() % allprobs.row(i).t();
    sumfoo        = sum(foo);
    lscale        = lscale+log(sumfoo);
    foo           = foo/sumfoo;
    lalpha.col(i) = log(foo)+lscale;
  }
  for(i=0;i<K;i++) {
    foo(i)=1.0/K;
  }
  lscale = log(K);
  for(i=T-2;i>=0;i--){
    foo          = mGamma * (allprobs.row(i+1).t() % foo);
    lbeta.col(i) = log(foo)+lscale;
    sumfoo       = sum(foo);
    foo          = foo/sumfoo;
    lscale       = lscale+log(sumfoo);
  }
  
  List FS;
  FS["lalpha"]=lalpha;
  FS["lbeta"]=lbeta;
  
  return FS;
}

List HMMlalphabeta(arma::vec vY, arma::mat mGamma, arma::vec vMu, arma::vec vSigma2, int T, int K){
  
  arma::vec vDelta=getDelta( mGamma, K);
  
  arma::mat allprobs = GaussianLk(vY, vMu, vSigma2, K, T, 0);
  
  List FB=FFBS(allprobs, vDelta, mGamma, K, T);
  
  FB["allprobs"]=allprobs;
  
  return FB;
}

//[[Rcpp::export]]
List EM(arma::vec vY, int K, int maxIter=1e3, double tol=1e-8, bool constraintZero = true){
  
  List lStarting = StartingValueEM(vY, K);
  arma::vec vMu     = AccessListVectors_vec(lStarting, "vMu");
  arma::vec vSigma2 = AccessListVectors_vec(lStarting, "vSigma2");
  arma::mat mGamma  = AccessListVectors_mat(lStarting, "mGamma");
  
  if (constraintZero) {
    vMu.zeros();
  }
  arma::vec vMu_Next=vMu;
  arma::vec vSigma2_Next=vSigma2;
  arma::mat mGamma_Next=mGamma;
  
  int T = vY.size();
  
  List fb;
  arma::mat lalpha(K,T);
  arma::mat lbeta(K,T);
  arma::mat allprobs(T,K);
  arma::mat SmoothProb(T,K);
  arma::mat PredictedProb(T,K);
  arma::mat FilteredProb(T,K);
  
  int iter=0;
  int i,j,b;
  
  arma::vec LLKSeries(maxIter+1);
  
  double eps = 1.0;
  
  fb     = HMMlalphabeta(vY, mGamma, vMu, vSigma2, T, K);
  lalpha = AccessListVectors_mat(fb, "lalpha");
  
  double c   = max(lalpha.col(T-1));
  double llk = c + log(sum(exp(lalpha.col(T-1)-c)));
  
  LLKSeries(0) = llk;
  
  while(eps > tol && iter<maxIter){
    
    fb        = HMMlalphabeta(vY, mGamma, vMu, vSigma2, T, K);
    lalpha    = AccessListVectors_mat(fb, "lalpha");
    lbeta     = AccessListVectors_mat(fb, "lbeta");
    allprobs  = AccessListVectors_mat(fb, "allprobs");
    
    c   = max(lalpha.col(T-1));
    llk = c + log(sum(exp(lalpha.col(T-1)-c)));
    
    for (j=0;j<K;j++){
      for (b=0;b<K;b++){
        mGamma_Next(j,b) = mGamma(j,b) * sum(exp(lalpha.row(j).subvec(0,T-2).t()+log(allprobs.col(b).subvec(1,T-1))+lbeta.row(b).subvec(1,T-1).t()-llk));
      }
    }
    
    for(j=0;j<K;j++){
      mGamma_Next.row(j) = mGamma_Next.row(j)/sum(mGamma_Next.row(j));
      //Update Mu and Sigma
      SmoothProb.col(j)    = exp(lalpha.row(j) + lbeta.row(j) - llk).t();
      
      if (!constraintZero) {
        vMu_Next(j) = sum(SmoothProb.col(j) % vY)/sum(SmoothProb.col(j));
      }
      
      vSigma2_Next(j)      = sum(SmoothProb.col(j) % pow(vY-vMu_Next(j),2.0))/sum(SmoothProb.col(j));
    }
    //Store the llk
    LLKSeries(iter) = llk;
    iter += 1;
    
    if(iter>10)  eps = abs3((llk - LLKSeries(iter-2))/(LLKSeries(iter-2) + 1.0));
    
    //Update Parameters
    
    vMu     = vMu_Next;
    vSigma2 = vSigma2_Next;
    mGamma  = mGamma_Next;
    
  }
  double llk_foo=0;
  
  for(i=0;i<T;i++){
    c                   = max(lalpha.col(i));
    llk_foo             = c+log(sum(exp(lalpha.col(i)-c)));
    FilteredProb.row(i) = exp(lalpha.col(i).t() - llk_foo);
    if(i<T-1){
      PredictedProb.row(i+1) = FilteredProb.row(i) * mGamma ;
    }
  }
  PredictedProb.row(0) = SmoothProb.row(0);
  
  arma::vec vDelta = getDelta(mGamma_Next,K);
  
  List EMOut;
  
  EMOut["SmoothProb"]    = SmoothProb;
  EMOut["PredictedProb"] = PredictedProb;
  EMOut["FilteredProb"]  = FilteredProb;
  
  EMOut["lalpha"]     = lalpha;
  EMOut["lbeta"]      = lbeta;
  EMOut["LLKSeries"]  = LLKSeries;
  EMOut["vMu"]        = vMu_Next;
  EMOut["vSigma2"]    = vSigma2_Next;
  EMOut["vY"]         = vY;
  EMOut["mGamma"]     = mGamma_Next;
  EMOut["vDelta"]     = vDelta;
  EMOut["eps"]        = eps;
  EMOut["iter"]       = iter;
  
  return EMOut;
  
}

