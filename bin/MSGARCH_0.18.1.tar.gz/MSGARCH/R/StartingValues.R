
DistParNames <- function(sDist, bSkew) {
  
  if (bSkew) {
    if (sDist == "norm") {
      vNames = c("xi")
    } 
    if (sDist == "std") {
      vNames = c("nu", "xi")
    } 
    if (sDist == "ged") {
      vNames = c("nu", "xi")
    } 
  } else {
    if (sDist == "std") {
      vNames = c("nu")
    } 
    if (sDist == "ged") {
      vNames = c("nu")
    } 
  }
  return(vNames)
}

SwitchDistLabels <- function(vLabels) {
  
  vSwithLabels = vLabels
  
  for (i in 1:length(vLabels)) {
    sLabel = vLabels[i]
    if (sLabel == "normal") {
      vSwithLabels[i] = "norm"
    } 
    if (sLabel == "student") {
      vSwithLabels[i] = "std"
    } 
  }
  
  return(vSwithLabels)
}

StaticStarting_Uni <- function(sDist, bSkew) {
  
  if (bSkew) {
    if (sDist == "norm") {
      vTheta = c(xi = 1.0)
    } else {
      vTheta = c(nu = 7.0, xi = 1.0)
    }
  } else {
    vTheta = c(nu = 7.0)
  }
  
  vTheta_tilde = as.numeric(UnmapParameters_univ(vTheta, sDist, bSkew))
  
  return(vTheta_tilde)
}

ddist_ThetaParam <- function(dZ, vTheta, sDist, bSkew, bLog) {
  
  dPDF = 0.0
  
  if (!bSkew) {
    if (sDist == "norm") {
      dPDF = ddist(dZ, "norm", log = bLog)
    } else {
      dPDF = ddist(dZ, sDist, shape = vTheta[1], log = bLog)
    }
  } else {
    if (sDist == "norm") {
      dPDF = ddist(dZ, "norm", skew = vTheta[1], log = bLog)
    } else {
      dPDF = ddist(dZ, sDist, shape = vTheta[1], skew = vTheta[2], log = bLog)
    }
  }
  
  if (bLog) {
    if (dPDF < -1e50) {
      dPDF = -1e50
    }
  } else {
    if (dPDF < 1e-50) {
      dPDF = 1e-50
    }
  }
  
  return(dPDF)
  
}

Fit_StaticDist <- function(vZ, sDist, bSkew) {
  
  vTheta_tilde = StaticStarting_Uni(sDist, bSkew)
  
  iT = length(vZ)
  
  vNames = DistParNames(sDist, bSkew)
  
  optimizer = optim(vTheta_tilde, function(vTheta_tilde, vZ, iT, sDist, bSkew, vNames){
    
    vTheta = as.numeric(MapParameters_univ(vTheta_tilde, sDist, bSkew))
    names(vTheta) = vNames
    
    dLLK = dUnivLike(vZ, sDist, bSkew, dXi = vTheta["xi"], dNu = vTheta["nu"])
    
    return(-dLLK)
    
  }, vZ = vZ, iT = iT, sDist = sDist, bSkew = bSkew, vNames = vNames, method = "BFGS")
  
  vTheta =  as.numeric(MapParameters_univ(optimizer$par, sDist, bSkew))
  
  names(vTheta) = DistParNames(sDist, bSkew)
  
  return(vTheta)
  
}

VarianceTargeting <- function(dSigma2, sModel, vTheta) {
  
  if (sModel == "sGARCH") {
    dAlpha0 = dSigma2 * (1.0 - vTheta[1, "alpha1_1"] - vTheta[1, "beta_1"])
  }
  
  if (sModel == "gjrGARCH") {
    dAlpha0 = dSigma2 * (1.0 - vTheta[1, "alpha1_1"] - 0.5 * vTheta[1, "alpha2_1"] - vTheta[1, "beta_1"])
  }
  
  if (sModel == "eGARCH") {
    dAlpha0 = log(dSigma2) * (1.0 - vTheta[1, "beta_1"])
  }
  
  if (sModel == "tGARCH") {
    dAlpha0 = dSigma2 * (1.0 + (vTheta[1, "alpha1_1"] + vTheta[1, "alpha2_1"]) * 0.5 - vTheta[1, "beta_1"])
  }
  
  return(dAlpha0)
  
}

StartingValueMSGARCH <- function(y, spec) {
  
  K      = spec$K
  vSpec  = spec$name
  vModel = sapply(vSpec, function(x) unlist(strsplit(x, split = "_"))[1])
  vDist  = SwitchDistLabels(sapply(vSpec, function(x) unlist(strsplit(x, split = "_"))[2]))
  vSim   = sapply(vSpec, function(x) unlist(strsplit(x, split = "_"))[3]) == "skew"
  
  ## Do EM
  EM_Fit = EM(y, K)
  mSmoothedProb = EM_Fit$SmoothProb
  
  ## local decoding
  lY = list()
  for (k in 1:K) {
    lY[[k]] = y[mSmoothedProb[, k] > 1/K]
  }
  
  ## initialize transition probability matrix
  
  StartingGamma = t(EM_Fit$mGamma)
  vP = matrix(c(StartingGamma[-K, ]), nrow = 1)
  colnames(vP) = rep("P", length(vP))
  
  ## Initialize unconditional volatilties
  vSigma2 = EM_Fit$vSigma2
  
  ## initialize shape and skew
  
  lShapeSkew = list() 
  
  vT = lapply(lY, length)
  
  for (k in 1:K) {
    
    lShapeSkew[[k]] = NULL
    
    if (vT[[k]] > 100) {
      
      if ((vDist[k] != "norm") || (vSim[k])) {
        
        vZ = (lY[[k]] - mean(lY[[k]]))/sd(lY[[k]])
        lShapeSkew[[k]] = Fit_StaticDist(vZ, vDist[k], vSim[k]) 
        
      } 
    }
  }
  
  lSingleRegimeGaussianSpec = list()
  lSingleRegimeCoef = list()
  
  for (k in 1:K) {
    
    lSingleRegimeGaussianSpec[[k]] = create.spec(model = vModel[k], distribution = c("norm"),
                                                 do.skew = c(FALSE), do.mix = FALSE, 
                                                 do.shape.ind = FALSE)
    
    dAlpha0 = VarianceTargeting(vSigma2[k], vModel[k], lSingleRegimeGaussianSpec[[k]]$theta0)
    
    lSingleRegimeGaussianSpec[[k]]$theta0[1, "alpha0_1"] = dAlpha0
    
    if (vT[[k]] > 100) {
      
      Fit = MSGARCH::fit.mle(spec = lSingleRegimeGaussianSpec[[k]], y = lY[[k]])
      lSingleRegimeCoef[[k]] = Fit$theta
      
    } else {
      
      lSingleRegimeCoef[[k]] = lSingleRegimeGaussianSpec[[k]]$theta0
      
    }
    
    colnames(lSingleRegimeCoef[[k]]) = sapply(colnames(lSingleRegimeCoef[[k]]), function(x) {
      unlist(strsplit(x, split = "_"))[1]
    })
    
    if ((vDist[k] != "norm") || (vSim[k])) {
      
      foo = colnames(lSingleRegimeCoef[[k]])
      
      lSingleRegimeCoef[[k]] = cbind(lSingleRegimeCoef[[k]], matrix(lShapeSkew[[k]], nrow = 1))
      
      colnames(lSingleRegimeCoef[[k]]) = c(foo, names(lShapeSkew[[k]]))
    }
    
    colnames(lSingleRegimeCoef[[k]]) = paste(colnames(lSingleRegimeCoef[[k]]), k, sep = "_")
    
  }
  
  vTheta0 = cbind(do.call(cbind, lSingleRegimeCoef), vP)
  
  return(vTheta0)
  
}


