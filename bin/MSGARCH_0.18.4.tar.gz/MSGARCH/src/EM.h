#ifndef EM_H
#define EM_H

arma::vec getDelta(arma::mat gamma, int m);

#endif
