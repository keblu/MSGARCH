library(testthat)
library(MSGARCH)

test_check("MSGARCH")